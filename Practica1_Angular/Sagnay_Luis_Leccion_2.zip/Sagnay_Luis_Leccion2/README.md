# SagnayLuisLeccion2

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 20.0.1.


# 🌍 Agencia Travel - Sitio Web con Angular

Este proyecto es una aplicación web de una **agencia de viajes** desarrollada en Angular. Permite a los usuarios explorar tours, leer testimonios de clientes, y ponerse en contacto con la empresa. Utiliza tecnologías modernas como **Angular Standalone Components**, **TailwindCSS**, **Signals y Computed**, para una experiencia reactiva, modular y con diseño responsivo.

---

## 🧩 Características

✅ Diseño responsive con **TailwindCSS**  
✅ Navegación entre páginas con Angular Router  
✅ Componentes reutilizables (UI)  
✅ Manejo de estado reactivo con **signals**  
✅ Caracteres en vivo con `computed()`  
✅ Formulario de contacto validado  
✅ Separación por responsabilidades (layout, pages, ui)

---

## 📁 Estructura del Proyecto

src/
│
├── app/
│ ├── layout/
│ │ ├── header/ → Logo y navegación principal
│ │ └── footer/ → Pie de página
│ │
│ ├── pages/
│ │ ├── home/ → Página principal
│ │ ├── tours/ → Catálogo de tours (usa ui/card-tour)
│ │ ├── testimonials/ → Testimonios de clientes (usa ui/card-testimonials)
│ │ └── contact/ → Formulario de contacto con signals + computed
│ │
│ └── ui/
│ ├── card-tour/ → Componente de tarjeta de tour
│ └── card-testimonials/→ Componente de tarjeta de testimonio
│
├── assets/ → Imágenes y otros recursos estáticos
├── styles.css → TailwindCSS y estilos globales
└── main.ts → Bootstrap de la app

## Funcionalidades por página
### Home (/)
Introducción y bienvenida

Enlaces a tours y contacto

Estilo atractivo con fondo degradado

### Tours (/tours)
Listado de tarjetas de tours

Componente reutilizable CardTour

### Testimonials (/testimonials)
Opiniones de clientes

Diseño responsivo en cuadrícula

### Contact (/contact)
Formulario de contacto con validación

Uso de signals y computed para manejo de datos y longitud de mensaje


![alt text](image.png)
![alt text](image-1.png)
![alt text](image-3.png)
![alt text](image-2.png)

### Autor
Luis Sagnay
